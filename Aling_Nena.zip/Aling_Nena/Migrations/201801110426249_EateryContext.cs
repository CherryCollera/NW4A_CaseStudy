namespace Aling_Nena.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EateryContext : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Menu",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        MainDish = c.String(),
                        Dessert = c.String(),
                        Appetizer = c.String(),
                        Cakes = c.String(),
                        Bread = c.String(),
                        Pizza = c.String(),
                        Drinks = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Order",
                c => new
                    {
                        OrderID = c.Int(nullable: false, identity: true),
                        RequestID = c.Int(nullable: false),
                        PatientID = c.Int(nullable: false),
                        Menu_ID = c.Int(),
                    })
                .PrimaryKey(t => t.OrderID)
                .ForeignKey("dbo.Menu", t => t.Menu_ID)
                .Index(t => t.Menu_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Order", "Menu_ID", "dbo.Menu");
            DropIndex("dbo.Order", new[] { "Menu_ID" });
            DropTable("dbo.Order");
            DropTable("dbo.Menu");
        }
    }
}
