﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Aling_Nena.Models;

namespace Aling_Nena.DAL
{
	public class EateryInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<EateryContext>
	{
		protected override void Seed(EateryContext context)
		{
			var menu = new List<Menu>
			{
			new Menu{MainDish="Sinigang",Dessert="Ice cream",Appetizer="Tarts",Cakes="Choco Moist",Bread=("Spanish Bread"),Pizza="Hawaian",Drinks="Four Season"},

			};
			menu.ForEach(s => context.Menu.Add(s));
			context.SaveChanges();
			
			

		}
	}
}

