﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aling_Nena.Models
{
	public class Order
	{
		public int OrderID { get; set; }
		public int RequestID { get; set; }
		public int PatientID { get; set; }



		public virtual Menu Menu { get; set; }
	}
}