﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aling_Nena.Models
{
	public class Menu
	{
	public int ID { get; set; }
	public string MainDish { get; set; }
	public string Dessert { get; set; }
	public string Appetizer { get; set; }
	public string Cakes { get; set; }
	public string Bread { get; set; }
	public string Pizza { get; set; }
	public string Drinks { get; set; }

	public virtual ICollection<Order> Order { get; set; }
}
}