﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

using System.Text;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {

        string str = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\registration.mdf;Integrated Security=True;User Instance=True";
        SqlConnection con = new SqlConnection(str);


        string a = "insert into tbl_reguser(firstname,middlename,lastname,username,birthday,password,email)values(@firstname,@middlename,@lastname,@username,@birthday,@password,@email)";
        SqlCommand cmd = new SqlCommand(a, con);


        con.Open();

        cmd.Parameters.AddWithValue("@firstname", una.Text.ToString());

        cmd.Parameters.AddWithValue("@middlename", mid.Text.ToString());

        cmd.Parameters.AddWithValue("@lastname", huli.Text.ToString());

        cmd.Parameters.AddWithValue("@username", user.Text.ToString());

        cmd.Parameters.AddWithValue("@birthday", birt.Text.ToString());

        cmd.Parameters.AddWithValue("@password", pass.Text.ToString());

        cmd.Parameters.AddWithValue("@email", em.Text.ToString());

        cmd.ExecuteNonQuery();
        Response.Redirect("home.aspx");
        con.Close();
          
          
    }
       
}
           

