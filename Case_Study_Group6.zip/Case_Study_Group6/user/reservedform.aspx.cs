﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;


public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
   
     
    }
    protected void btngal_Click(object sender, EventArgs e)
    {
        Response.Redirect("gallery.aspx");
  


   


    

    }
    protected void btnsub_Click(object sender, EventArgs e)
    {

        string str = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\reserve.mdf;Integrated Security=True;User Instance=True";
        SqlConnection con = new SqlConnection(str);


        string a = "insert into tbl_reserve(car,address,city,country,license)values(@car,@address,@city,@country,@license)";
        SqlCommand cmd = new SqlCommand(a, con);


        con.Open();

        cmd.Parameters.AddWithValue("@car", car.Text.ToString());

        cmd.Parameters.AddWithValue("@address", address.Text.ToString());

        cmd.Parameters.AddWithValue("@city", city.Text.ToString());

        cmd.Parameters.AddWithValue("@country", country.Text.ToString());

        cmd.Parameters.AddWithValue("@license", license.Text.ToString());


        cmd.ExecuteNonQuery();
        Response.Redirect("reservedform.aspx");
        con.Close();
    }
}
