﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void bntnext_Click(object sender, EventArgs e)
    {


        string str = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\car.mdf;Integrated Security=True;User Instance=True";
        SqlConnection con = new SqlConnection(str);


        string a = "insert into tbl_rent(car_name,no_of_days,schedule,date_rented,date_closed,contact_number)values(@car_name,@no_of_days,@schedule,@date_rented,@date_closed,@contact_number)";
        SqlCommand cmd = new SqlCommand(a, con);


        con.Open();


        cmd.Parameters.AddWithValue("@no_of_days", day.Text.ToString());

        cmd.Parameters.AddWithValue("@schedule", schedule.Text.ToString());

        cmd.Parameters.AddWithValue("@date_rented", start.Text.ToString());

        cmd.Parameters.AddWithValue("@date_closed", closed.Text.ToString());

        cmd.Parameters.AddWithValue("@contact_number", contact.Text.ToString());



        cmd.ExecuteNonQuery();
        Response.Redirect("Payment.aspx");
        con.Close();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
