﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btncompute_Click1(object sender, EventArgs e)
    {
        decimal a = decimal.Parse(car.Text);
        decimal b = decimal.Parse(day.Text);
        decimal c = a *b;
        lbltotal.Text = c.ToString();

    }
    protected void btnsub_Click(object sender, EventArgs e)
    {
        string str = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Bill.mdf;Integrated Security=True;User Instance=True";
        SqlConnection con = new SqlConnection(str);


        string a = "insert into tbl_bill(customerid,car_amount,total_no_of_days,total)values(@customerid,@car_amount,@total_no_of_days,@total)";
        SqlCommand cmd = new SqlCommand(a, con);


        con.Open();

        cmd.Parameters.AddWithValue("@customerid", customer.Text.ToString());

        cmd.Parameters.AddWithValue("@car_amount", car.Text.ToString());

        cmd.Parameters.AddWithValue("@total_no_of_days", day.Text.ToString());

        cmd.Parameters.AddWithValue("@total", lbltotal.Text.ToString());

      

        cmd.ExecuteNonQuery();
        Response.Redirect("");
        con.Close();
          
    }
}

